let isDepthEnabled = false;
let isClassEnabled = false;

function highlightDepth(element, depth = 0) {
  if (!element || element.nodeType !== 1) return;

  const colors = [
    "#ff0000", "#ff7f00", "#ffff00", "#7fff00", "#00ff00",
    "#00ff7f", "#00ffff", "#007fff", "#0000ff", "#7f00ff",
    "#ff00ff", "#ff007f"
  ];

  element.style.outline = `2px solid ${colors[depth % colors.length]}`;
  element.setAttribute("data-depth-debug", depth);

  Array.from(element.children).forEach((child) => highlightDepth(child, depth + 1));
}

function removeHighlight() {
  document.querySelectorAll("[data-depth-debug]").forEach(el => {
    el.style.outline = "none";
    el.removeAttribute("data-depth-debug");
  });
}

function showClassNames() {
    console.log("Showing class names");  // Логування для перевірки
    if (!isClassEnabled) return; // Якщо підсвічування класів вимкнене, припинити виконання
  
    document.querySelectorAll("*").forEach(element => {
      if (!element.classList.length) return;
  
      // Додаємо слухач подій для наведення мишки
      element.addEventListener("mouseover", () => {
        let tooltip = document.createElement("div");
        tooltip.className = "class-tooltip";
        tooltip.innerText = `.${Array.from(element.classList).join(" .")}`;
  
        let rect = element.getBoundingClientRect();
        tooltip.style.top = `${window.scrollY + rect.top - 20}px`;
        tooltip.style.left = `${window.scrollX + rect.left}px`;
  
        document.body.appendChild(tooltip);
        element.setAttribute("data-class-debug", "true");
  
        // Зберігаємо посилання на тултип для видалення його при mouseout
        element.addEventListener("mouseout", () => {
          tooltip.remove();
          element.removeAttribute("data-class-debug");
        });
      });
    });
  }
  
  function removeClassNames() {
    console.log("Removing class names");  // Логування для перевірки
    document.querySelectorAll(".class-tooltip").forEach(el => el.remove());
    document.querySelectorAll("[data-class-debug]").forEach(el => el.removeAttribute("data-class-debug"));
  }
  
  
  function removeClassNames() {
    document.querySelectorAll(".class-tooltip").forEach(el => el.remove());
    document.querySelectorAll("[data-class-debug]").forEach(el => el.removeAttribute("data-class-debug"));
  }
  

chrome.storage.local.get(["depthEnabled", "classEnabled"], (data) => {
  isDepthEnabled = data.depthEnabled || false;
  isClassEnabled = data.classEnabled || false;

  if (isDepthEnabled) {
    highlightDepth(document.body);
    isClassEnabled = true; // Enable class highlighting when depth is enabled
    showClassNames();
  }
});

chrome.runtime.onMessage.addListener((message) => {
  if (message.action === "toggleDebug") {
    isDepthEnabled = !isDepthEnabled;
    chrome.storage.local.set({ depthEnabled: isDepthEnabled });

    if (isDepthEnabled) {
      highlightDepth(document.body);
      isClassEnabled = true; // Enable class highlighting when depth is enabled
      showClassNames();
    } else {
      removeHighlight();
      removeClassNames(); // Disable class highlighting when depth is turned off
    }
  }
});
