chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.local.set({ depthEnabled: false, classEnabled: false });
  });
  
  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === "toggleDebug") {
      // Тоглінг для підсвічування глибини
      isDepthEnabled = !isDepthEnabled;
      chrome.storage.local.set({ depthEnabled: isDepthEnabled });
  
      // Тоглінг для підсвічування класів
      console.log("Depth enabled:", isDepthEnabled);  // Логування для перевірки
  
      if (isDepthEnabled) {
        // Якщо підсвічування глибини увімкнене
        highlightDepth(document.body);
        isClassEnabled = true;  // Увімкнути підсвічування класів
        showClassNames();  // Показати іменування класів
      } else {
        // Якщо підсвічування глибини вимкнене
        console.log("Removing highlights and class names");  // Логування для перевірки
        removeHighlight();  // Прибираємо підсвічування глибини
        removeClassNames();  // Прибираємо підсвічування класів
        isClassEnabled = false;  // Вимикаємо підсвічування класів
      }
    }
  });
  